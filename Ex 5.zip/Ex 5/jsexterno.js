
   
   function calcularmedia()
    {
        var n1 = parseFloat(document.getElementById('n1').value);
        var n2 = parseFloat(document.getElementById('n2').value);
        var media = (n1 + n2)/2;
        document.getElementById('media').value = media;

        if (media < 5){
        document.body.style.background = "red"
        document.getElementById('resultado').src = "reprovado.jpg";
        }

        else if (media > 6){
        document.body.style.background = "Green"
        document.getElementById('resultado').src = "aprovado.jpg";
        }

        else{
        document.body.style.background  = "Yellow"
        document.getElementById('resultado').src = "recuperação.jpg";
        }
        
    }
