
    var historico = document.getElementById('historico');
   

    function soma()
    {
        var n1 = parseFloat(document.getElementById('num1').value);
        var n2 = parseFloat(document.getElementById('num2').value);
        var soma = n1 + n2;
        historico.innerHTML += '<p>' + soma + '</p>';
    }

    function subtracao()
    {
        var n1 = parseFloat(document.getElementById('num1').value);
        var n2 = parseFloat(document.getElementById('num2').value);
        var subtracao = n1 - n2;
        document.getElementById('result').value = subtracao;
        historico.innerHTML += '<p>' + subtracao + '</p>';
    }

    function multiplicacao()
    {
        var n1 = parseFloat(document.getElementById('num1').value);
        var n2 = parseFloat(document.getElementById('num2').value);
        var multiplicacao = n1 * n2;
        document.getElementById('result').value = multiplicacao;
        historico.innerHTML += '<p>' + multiplicacao  + '</p>';
    }

    function divisao()
    {
        var n1 = parseFloat(document.getElementById('num1').value);
        var n2 = parseFloat(document.getElementById('num2').value);
        var divisao = n1 / n2;
        document.getElementById('result').value = divisao;
        historico.innerHTML += '<p>' + divisao + '</p>';
        
    }

